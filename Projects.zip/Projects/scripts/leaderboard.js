window.addEventListener("DOMContentLoaded", async () => {
  try {
    const leaderboard = await apiRequest("/leaderboard");

    const table = document.getElementById("leaderboardBody");
    leaderboard.forEach((user, index) => {
      const row = `<tr>
        <td>${index + 1}</td>
        <td>${user.username}</td>
        <td>${user.level}</td>
        <td>${user.xp}</td>
      </tr>`;
      table.innerHTML += row;
    });
  } catch (err) {
    console.error("Failed to load leaderboard:", err.message);
  }
});