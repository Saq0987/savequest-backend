window.addEventListener("DOMContentLoaded", async () => {
  const token = localStorage.getItem("token");
  if (!token) return window.location.href = "login.html";

  try {
    const user = await apiRequest("/user", "GET", null, token);
    document.getElementById("username").textContent = user.username;
    document.getElementById("xp").textContent = `${user.xp} XP`;
    document.getElementById("level").textContent = user.level;
  } catch (err) {
    alert("Session expired. Please login again.");
    localStorage.removeItem("token");
    window.location.href = "login.html";
  }
});